﻿using System;

namespace CRUDDemo
{
    public class Entitybase : IEntitybase
    {
        public int Id { get; set; }
        public Guid GUID { get; set; }
    }
}
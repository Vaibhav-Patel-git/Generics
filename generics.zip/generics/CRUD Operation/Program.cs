﻿using CRUDOperation.Data;
using CRUDOperation.Repositories;
using System;

namespace CRUDOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            var repoEmployee = new SQLRepository<Employee, int>(new EmployeeDBContext());
            AddEmployee(repoEmployee);

            AddManager(repoEmployee);
            GetEmployeeById(repoEmployee);

            var repoOrganization = new SQLRepository<Organization, int>(new EmployeeDBContext());
            AddOrganization(repoOrganization);

           
            GetAll(repoEmployee);
            GetAll(repoOrganization);
            Console.ReadKey();
        }
        private static void AddManager(IWriteRepository<Manager, int> repoManager)
        {
            repoManager.Add(new Manager() { Id = 4, EmployeeName = "chaman" });
            repoManager.Add(new Manager() { Id = 5, EmployeeName = "lal" });
            repoManager.Save();
        }
        private static void AddEmployee(IRepository<Employee, int> gre)
        {
            gre.Add(new Employee() { Id = 1, EmployeeName = "Ram" });
            gre.Add(new Employee() { Id = 2, EmployeeName = "shyam" });
            gre.Add(new Employee() { Id = 3, EmployeeName = "dhyan" });
            gre.Save();
        }

        private static void GetAll(IReadRepository<IEntitybase, int> gre)
        {
            foreach (var item in gre.GetAll()) 
                Console.WriteLine(item);
        }

        private static void GetEmployeeById(IRepository<Employee, int> gre)
        {
            gre.GetById(1);
        }

      
        private static void AddOrganization(IRepository<Organization, int> repoOrganization)
        {
            repoOrganization.Add(new Organization() { GUID = Guid.NewGuid(), Name = "abc" });
            repoOrganization.Add(new Organization() { GUID = Guid.NewGuid(), Name = "torrent" });
            repoOrganization.Add(new Organization() { GUID = Guid.NewGuid(), Name = "power" });
            repoOrganization.Save();
        }

    }
}

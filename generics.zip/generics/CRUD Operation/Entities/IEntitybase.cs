﻿using System;

namespace CRUDOperation
{
    public interface IEntitybase
    {
        Guid GUID { get; set; }
        int Id { get; set; }
    }
}
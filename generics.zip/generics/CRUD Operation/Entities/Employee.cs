﻿namespace CRUDOperation
{
    public class Employee : Entitybase
    {
        public string EmployeeName { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}, EmployeeName: {EmployeeName}";
        }
    }
}
﻿using System;

namespace CRUDDemo
{
    public interface IEntitybase
    {
        Guid GUID { get; set; }
        int Id { get; set; }
    }
}
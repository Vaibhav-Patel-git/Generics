﻿namespace CRUDOperation.Repositories
{

    // contravarience concept by usin in keyword at type T
    // which allow parent child class to use
    public interface IWriteRepository<in T, TKey>
      where T : class, IEntitybase
      where TKey : struct
    {
        void Add(T item);
        void Remove(T item);
        void Save();
    }
}
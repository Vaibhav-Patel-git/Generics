﻿using System;

namespace generics
{
    public class SimpleStack<T>
    {
        private readonly T[] _items;
        private int _currentIndex = -1;
        public SimpleStack() => _items = new T[10];
        public void Push(T item) => _items[++_currentIndex] = item;
        public int Count => _currentIndex + 1;

        public T Pop() => _items[_currentIndex--];
    }

    public class SimpleStackObject
    {
        private readonly object[] _items;
        private int _currentIndex = -1;
        public SimpleStackObject() => _items = new object[10];
        public void Push(object item) => _items[++_currentIndex] = item;
        public int Count => _currentIndex + 1;

        public object Pop() => _items[_currentIndex--];
    }

    public class SimpleStackString
    {
        private readonly String[] _items;
        private int _currentIndex = -1;
        public SimpleStackString() => _items = new String[10];
        public void Push(String item) => _items[++_currentIndex] = item;
        public int Count => _currentIndex + 1;

        public String Pop() => _items[_currentIndex--];
    }

    public class SimpleStackDouble
    {
        private readonly double[] _items;
        private int _currentIndex = -1;
        public SimpleStackDouble() => _items = new double[10];
        public void Push(double item) => _items[++_currentIndex] = item;
        public int Count => _currentIndex + 1;

        public double Pop() => _items[_currentIndex--];
    }

}
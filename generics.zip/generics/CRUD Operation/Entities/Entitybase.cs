﻿using System;

namespace CRUDOperation
{
    public class Entitybase : IEntitybase
    {
        public int Id { get; set; }
        public Guid GUID { get; set; }
    }
}
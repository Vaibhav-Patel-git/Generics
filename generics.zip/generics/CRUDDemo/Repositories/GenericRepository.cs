﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRUDDemo.Repositories
{
    public class GenericRepository<T, TKey>
    {
        public TKey Key { get; set; }
        protected readonly List<T> Items = new List<T>();
        public void Add(T item) => Items.Add(item);

        public void Save()
        {
            foreach (var item in Items) Console.WriteLine(item);
        }
    }
}

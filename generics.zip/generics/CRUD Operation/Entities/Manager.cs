﻿namespace CRUDOperation
{
    public class Manager : Employee
    {
        public override string ToString()
        {
            return $"Id: {Id}, EmployeeName: {EmployeeName}, Manager";
        }
    }
}
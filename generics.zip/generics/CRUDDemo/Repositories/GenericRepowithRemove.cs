﻿using System.Linq;

namespace CRUDDemo.Repositories
{
    public class GenericRepowithRemove<T, TKey> : GenericRepository<T, TKey>
         //where T : Entitybase // it says it is reference type as class type constraint given
         where T : IEntitybase,new()  // it says it is reference & value type both as interface type constraint given
        where TKey : struct // means Tkey is value type
    {
        public void Remove(T item) => Items.Remove(item);

        public T GetById(TKey key) => typeof(TKey) == typeof(int) ? Items.Single(a => a.Id.ToString() == key.ToString())
                : Items.Single(a => a.GUID.ToString() == key.ToString());

        //public T GetById(TKey key) => default(T);

        public T CreateItem() => new T();
    }
}

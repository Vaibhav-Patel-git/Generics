﻿using CRUDDemo.Repositories;
using System;

namespace CRUDDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            GenericRepowithRemove<Employee, int> gre = new GenericRepowithRemove<Employee, int>();
            gre.Add(new Employee() { Id = 1, EmployeeName = "Ram" });
            gre.Add(new Employee() { Id = 2, EmployeeName = "shyam" });
            gre.Add(new Employee() { Id = 3, EmployeeName = "dhyan" });
            gre.Save();

            gre.Remove(gre.GetById(1));
            gre.Save();
            Employee emp = gre.CreateItem();
            Guid temp = Guid.NewGuid();
            GenericRepowithRemove<Organization, Guid> gro = new GenericRepowithRemove<Organization, Guid>();
            gro.Add(new Organization() { GUID = temp, Name = "abc" });
            gro.Add(new Organization() { GUID = Guid.NewGuid(), Name = "torrent" });
            gro.Add(new Organization() { GUID = Guid.NewGuid(), Name = "power" });
            gro.Save();

            gro.Remove(gro.GetById(temp));
            gro.Save();


            Console.ReadKey();
        }
    }
}

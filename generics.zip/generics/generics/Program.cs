﻿using System;

namespace generics
{
    class Program
    {
        static void Main(string[] args)
        {
            StackDoubles();
            StackStrings();
            StackGenericsstring();
            StackGenerickDoubles();
            Console.ReadLine();
        }
        private static void StackDoubles()
        {
            var stack = new SimpleStackObject();
            stack.Push(1.2);
            stack.Push(6.2);
            stack.Push(8.2);
            double sum = 0;
            while (stack.Count > 0)
            {
                double item = (double)stack.Pop();
                Console.WriteLine($"Item - {item}");
                sum += item;
            }
            Console.WriteLine($"Sum - {sum}");
        }
        private static void StackStrings()
        {
            var stack = new SimpleStackObject();
            stack.Push("1.2");
            stack.Push("6.2");
            stack.Push("8.2");

            while (stack.Count > 0)
            {
                object item = stack.Pop();
                Console.WriteLine($"Item - {item}");
            }
        }

        private static void StackGenericsstring()
        {
            var stack = new SimpleStack<string>();
            stack.Push("1.2");
            stack.Push("6.2");
            stack.Push("8.2");

            while (stack.Count > 0)
            {
                object item = stack.Pop();
                Console.WriteLine($"Item - {item}");
            }
        }

        private static void StackGenerickDoubles()
        {
            var stack = new SimpleStack<double>();
            stack.Push(1.2);
            stack.Push(6.2);
            stack.Push(8.2);
            double sum = 0;
            while (stack.Count > 0)
            {
                double item = (double)stack.Pop();
                Console.WriteLine($"Item - {item}");
                sum += item;
            }
            Console.WriteLine($"Sum - {sum}");
        }
    }
}

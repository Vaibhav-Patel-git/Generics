﻿using System.Collections.Generic;

namespace CRUDOperation.Repositories
{

    //Covarience concept by using out prameter on T 
    // which allows less tightly coupled type declaration
    public interface IReadRepository<out T, TKey> 
       where T : class, IEntitybase
       where TKey : struct
    {
        TKey Key { get; set; }
        IEnumerable<T> GetAll();
        T GetById(TKey key);
    }
}
﻿using System;

namespace CRUDDemo
{
    public class Organization : Entitybase
    {
        public string Name { get; set; }

        public override string ToString()
        {
            return $"GUID: {GUID}, Name: {Name}";
        }
    }
}
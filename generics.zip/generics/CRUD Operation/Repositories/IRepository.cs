﻿namespace CRUDOperation.Repositories
{
    public interface IRepository<T, TKey> : IReadRepository<T, TKey>, IWriteRepository<T, TKey>
        where T : class,IEntitybase
        where TKey : struct
    {
    }
}
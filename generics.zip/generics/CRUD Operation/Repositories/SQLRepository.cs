﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CRUDOperation.Repositories
{
    public class SQLRepository<T, TKey> : IRepository<T, TKey> where T : class,IEntitybase
       where TKey : struct
    {
        private readonly DbContext dbcontext;
        private readonly DbSet<T> dbset;

        public SQLRepository(DbContext dbcontext)
        {
            this.dbcontext = dbcontext;
            dbset = dbcontext.Set<T>();
        }
        public TKey Key { get; set; }
        public void Add(T item) => dbset.Add(item);
        public void Remove(T item) => dbset.Remove(item);
        public T GetById(TKey key) => typeof(TKey) == typeof(int) ? dbset.Single(a => a.Id.ToString() == key.ToString())
               : dbset.Single(a => a.GUID.ToString() == key.ToString());
        public void Save() => dbcontext.SaveChanges();

        public IEnumerable<T> GetAll()
        {
            return dbset.ToList();
        }

    }
}
